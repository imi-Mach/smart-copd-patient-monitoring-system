![Main image](https://raw.githubusercontent.com/cunningham-code/qolab/master/static/qolab-master-photo.png)

# This is QoLab

A way to make study plans with friends over lo-fi beats!

Run:
python3 manage.py migrate
python3 manage.py runserver
